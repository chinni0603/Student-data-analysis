<?php

$databaseHost = 'localhost:3306';
$databaseName = 'mini project';
$databaseUsername = 'root';
$databasePassword = '';
$mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName);

?>
