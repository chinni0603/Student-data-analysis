<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Login Page</title>
    <link rel="stylesheet" href=
"https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="logstyle.css">
  </head>
  <body>
    <h1 style="color:blue; text-align:center;">Login as Principal</h1>
    <fieldset class="login">
      <legend align="center"><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQX-BH0rwTlqY-_4BGCB_EYWt0vkOJkI8aBDQ&usqp=CAU" width="38" height="38"></legend>
      <form name="sform"  class="form" action="validate.php" method="post">
    		<input type="text" class="uname" name="uname" size="25" placeholder="USERNAME"><br><br>
    		<input type="password"class="uname" name="password" size="25" placeholder="PASSWORD"><br><br>
    	 <input type="submit" name="Submit"  class="sub" value="Submit">
    	</form>
    </fieldset>
  </body>
</html>
